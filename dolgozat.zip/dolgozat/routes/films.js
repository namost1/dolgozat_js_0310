import express from "express"
import { createFilm, deleteFilm, getAllFilms, getFilmsById, updateFilm } from "../controllers/filmControllers.js"
const router = express.Router()
router.get('/', getAllFilms)
router.get('/:id', getFilmsById)
router.post('/', createFilm)
router.put('/:id', updateFilm)
router.delete('/:id', deleteFilm)
export default router