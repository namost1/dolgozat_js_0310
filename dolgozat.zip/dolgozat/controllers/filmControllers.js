import films from '../data/films.js'

export const getAllFilms = (req, res) => {
    res.status(200).json(films)
}
export const getFilmsById = (req, res) => {
    const id = req.params.id
    if(id < 0 || id >= films.length){
        return res.status(404).json({message: "film not found"})
    }
    res.status(200).json(films[id])
}
export const createFilm = (req, res) => {
    const {title, director, year, oscar} = req.body
    if(!title || !director || !year || !oscar){
        return res.status(404).json({message: "Missing data"})
    }
    const newFilm = {title, director, year, oscar}
    films.push(newFilm)
    res.status(201).json(newFilm)
}
export const updateFilm = (req, res) => {
    const id = req.params.id
    if(id < 0 || id >= films.length){
        return res.status(404).json({message: "film not found"})
    }
    const {title, director, year, oscar} = req.body
    if(!title || !director || !year || !oscar){
        return res.status(404).json({message: "Missing data"})
    }
    films[id] = {title, director, year, oscar}
    res.status(200).json(films[id])
}
export const deleteFilm = (req, res) => {
    const id = req.params.id
    if(id < 0 || id >= films.length){
        return res.status(404).json({message: "film not found"})
    }
    films.splice(id,1)
    res.status(200).json({message: "delete successfull"})
}