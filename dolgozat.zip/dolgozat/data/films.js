const films = [
    {title: "Revange of the Sith", director: "Bekre Pál", year: 2005, oscar: "false"},
    {title: "Mindenki", director: "Fá Zoltán", year: 2010, oscar: "true"},
    {title: "The Empire strikes back", director: "Hát Izsák", year: 1977, oscar: "false"}
]
export default films